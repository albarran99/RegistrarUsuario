package org.iesfm.registrarUsuario;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.Scanner;

public class NameFinder {

    private static final Logger log = LoggerFactory.getLogger(CheckInMain.class);
    private static final Scanner scan = new Scanner(System.in);

    public String readFile(String text, File file) throws FileNotFoundException {
        StringBuilder builder = new StringBuilder();

        try (BufferedReader reader =
                     new BufferedReader(
                             new FileReader(file)
                     )
        ) {
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line).append("\n");
                if (line.equals(text)) {
                    log.info("Usuario ya exixtente " + text);
                    System.exit(1);
                }


            }

            log.info("Usuario Registrado");

        } catch (IOException e) {
            e.printStackTrace();
        }

        return builder.toString();

    }
}
